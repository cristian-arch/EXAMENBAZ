package com.example.curso.util;

import com.example.curso.model.JwtUser;
import com.example.curso.security.JwtGenerator;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class start {

    public static  boolean validarFecha(String dia,String mes,String anio) {






        boolean estatus = false;

        try {
            //Formato de fecha (día/mes/año)
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            formatoFecha.setLenient(false);
            //Comprobación de la fecha
            formatoFecha.parse(dia + "/" + mes + "/" + anio);
            estatus = true;
        } catch (ParseException e) {
            //Si la fecha no es correcta, pasará por aquí
            estatus = false;
        }

        return estatus;
    }


    public static void main(String args[]){
        JwtGenerator jwtGenerator=new JwtGenerator();
        JwtUser jwtUser=new JwtUser();
        String token=jwtGenerator.generate(jwtUser);
        System.out.println("token->"+token);

        String fechaEntrada="18/03/1993";

        String[] part=fechaEntrada.split("/");

        System.out.println("..lllll->"+part[1]);

        System.out.println("es ->" + validarFecha(part[0],part[1],part[2]));

    }
}
