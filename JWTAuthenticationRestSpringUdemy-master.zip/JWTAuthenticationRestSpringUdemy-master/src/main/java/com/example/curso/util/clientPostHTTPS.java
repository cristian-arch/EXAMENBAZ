package com.example.curso.util;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;

public class clientPostHTTPS {

    public void  test1(){


        String urlParameters = "param1=a&param2=b&param3=c";

        try {
            URL url = new URL("https://via.pagosbanorte.com/payw2");
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());

            writer.write(urlParameters);
            writer.flush();

            String line;
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            writer.close();
            reader.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void Tets2(){
        String data = "data=Hello+World!";

        URL url = null;
        try {
            url = new URL("http://localhost:8084/WebListenerServer/webListener");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.getOutputStream().write(data.getBytes("UTF-8"));
            con.getInputStream();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void testHTTPS(){
        String httpsURL = "https://your.https.url.here/";

        try {
            URL myUrl = new URL (httpsURL);
            HttpsURLConnection conn = (HttpsURLConnection) myUrl.openConnection ();
            InputStream es = conn.getInputStream ();
            InputStreamReader isr = new InputStreamReader (es);
            BufferedReader br = new BufferedReader (isr);

            String inputLine;

            while ((inputLine = br.readLine ()) != null) {
                System.out.println (inputLine);
            }

            br.close ();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}
