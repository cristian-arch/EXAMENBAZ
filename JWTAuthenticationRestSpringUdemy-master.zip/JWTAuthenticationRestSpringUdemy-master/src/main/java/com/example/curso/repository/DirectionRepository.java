package com.example.curso.repository;

import com.example.curso.model.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DirectionRepository extends JpaRepository<Direccion, Long> {


}
