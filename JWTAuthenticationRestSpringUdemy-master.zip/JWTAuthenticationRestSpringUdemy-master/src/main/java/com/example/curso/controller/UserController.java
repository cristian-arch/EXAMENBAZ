package com.example.curso.controller;

import com.example.curso.model.Direccion;
import com.example.curso.model.usuarios;
import com.example.curso.repository.UsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    UsuariosRepository usuariosRepository;
    @PostMapping("/SaveUser")
    public ResponseEntity<usuarios> SaveUser(@RequestBody usuarios userRequest) {




        if(validarFecha(userRequest.getFechaNacimiento())) {
            try {
                usuarios _user = usuariosRepository
                        .save(new usuarios(userRequest.getNombre(), userRequest.getApellidoPaterno(), userRequest.getApellidoMaterno(), userRequest.getFechaNacimiento()));

                _user.setEstatus(true);
                _user.setMensaje("exitoso");
                return new ResponseEntity<>(_user, HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }else{
            userRequest.setEstatus(false);
            userRequest.setMensaje("el formato de fecha no es valido");
            return new ResponseEntity<>(userRequest, HttpStatus.BAD_REQUEST);
        }

    }


    @GetMapping("/ConsulUser")
    public ResponseEntity<List<usuarios>> ConsulUser(@RequestParam(required = false) String nombreUsuario) {
        try {
            List<usuarios> usuarioList = new ArrayList<usuarios>();
            if (nombreUsuario == null)
                usuariosRepository.findAll().forEach(usuarioList::add);

            if (usuarioList.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(usuarioList, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/consulById/{id}")
    public ResponseEntity<usuarios> consulById(@PathVariable("id") long id) {
        Optional<usuarios> usuariosdata = usuariosRepository.findById(id);
        if (usuariosdata.isPresent()) {
            return new ResponseEntity<>(usuariosdata.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PutMapping("/updateUser/{id}")
    public ResponseEntity<usuarios> updateUser(@PathVariable("id") long id, @RequestBody usuarios usuariosRequest) {
        Optional<usuarios> tutorialData = usuariosRepository.findById(id);
        if (tutorialData.isPresent()) {
            usuarios usuarios = tutorialData.get();


            usuarios.setNombre(usuariosRequest.getNombre());
            usuarios.setApellidoMaterno(usuariosRequest.getApellidoMaterno());
            usuarios.setApellidoPaterno(usuariosRequest.getApellidoPaterno());
            usuarios.setFechaNacimiento(usuariosRequest.getFechaNacimiento());

            return new ResponseEntity<>(usuariosRepository.save(usuarios), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/deleteUser/{id}")
    public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") long id) {
        try {
            usuariosRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    public boolean validarFecha(String fechas) {


        String[] part=fechas.split("/");
        boolean estatus = false;

        try {
            //Formato de fecha (día/mes/año)
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            formatoFecha.setLenient(false);
            //Comprobación de la fecha
            formatoFecha.parse(part[0]+ "/" + part[1]+ "/" +part[2]);
            estatus = true;
        } catch (ParseException e) {
            //Si la fecha no es correcta, pasará por aquí
            estatus = false;
        }

        return estatus;
    }

}
