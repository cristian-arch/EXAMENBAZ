package com.example.curso.controller;

import com.example.curso.model.Direccion;
import com.example.curso.model.cuenta;
import com.example.curso.model.usuarios;
import com.example.curso.repository.CuentasRepository;
import com.example.curso.repository.UsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class CuentasController {

    @Autowired
    CuentasRepository cuentasRepository;

    @PostMapping("/SaveUserCuenta")
    public ResponseEntity<cuenta> SaveUserCuenta(@RequestBody cuenta userRequestCuenta) {

        if(String.valueOf(userRequestCuenta.getNumeroCuenta()).length()==10) {

            System.out.println("***");
            try {
                cuenta _cuenta = cuentasRepository
                        .save(new cuenta(userRequestCuenta.getNumeroCuenta(), userRequestCuenta.getIngresos(), userRequestCuenta.getIdUsuario(), userRequestCuenta.getIdDireccion()));

                System.out.println("^^^");
                _cuenta.setEstatus(true);
                _cuenta.setMensaje("exitoso");
                return new ResponseEntity<>(_cuenta, HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }else{

            userRequestCuenta.setEstatus(false);
            userRequestCuenta.setMensaje("el campo cuenta debe tener 10 digitos ");

            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/ConsulUserCuenta")
    public ResponseEntity<List<cuenta>> ConsulUserCuenta(@RequestParam(required = false) String nombreUsuario) {
        try {
            List<cuenta> usuarioListCuenta = new ArrayList<cuenta>();
            if (nombreUsuario == null)
                cuentasRepository.findAll().forEach(usuarioListCuenta::add);

            if (usuarioListCuenta.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(usuarioListCuenta, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/consulByIdCuentasUsuarios/{id}")
    public ResponseEntity<cuenta> consulByIdCuentasUsuarios(@PathVariable("id") long id) {
        Optional<cuenta> usuariosdata = cuentasRepository.findById(id);
        if (usuariosdata.isPresent()) {
            return new ResponseEntity<>(usuariosdata.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PutMapping("/updateUserCuentas/{id}")
    public ResponseEntity<cuenta> updateUserCuentas(@PathVariable("id") long id, @RequestBody cuenta usuariosRequestCuenta) {
        Optional<cuenta> tutorialData = cuentasRepository.findById(id);
        if (tutorialData.isPresent()) {
            cuenta cuenta = tutorialData.get();
            cuenta.setNumeroCuenta(usuariosRequestCuenta.getNumeroCuenta());
            cuenta.setIngresos(usuariosRequestCuenta.getIngresos());
            cuenta.setIdUsuario(usuariosRequestCuenta.getIdUsuario());
            cuenta.setIdDireccion(usuariosRequestCuenta.getIdDireccion());
            return new ResponseEntity<>(cuentasRepository.save(cuenta), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/deleteUserCuenta/{id}")
    public ResponseEntity<HttpStatus> deleteUserCuenta(@PathVariable("id") long id) {
        try {
            cuentasRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



}
