package com.example.curso.repository;

import com.example.curso.model.Direccion;
import com.example.curso.model.cuenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CuentasRepository extends JpaRepository<cuenta, Long> {
}
