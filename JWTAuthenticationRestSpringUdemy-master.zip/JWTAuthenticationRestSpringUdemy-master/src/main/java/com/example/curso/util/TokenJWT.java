package com.example.curso.util;



import com.example.curso.constants.Constants;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class TokenJWT {

    private String secret="1234567890";

    private String issuer="1234567890";

    public String TokenJWT(String usuario, String idUsuario  , String roles) throws UnsupportedEncodingException {



        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MINUTE, 2);
        Date expireDate = calendar.getTime();


        String jwtToken = Jwts.builder()
                .claim("admin", roles)
                .setSubject(usuario)
                .setIssuer(idUsuario)
                .setIssuedAt(date)
                .setExpiration(expireDate)
                .signWith(SignatureAlgorithm.HS512,"12345678" )
                .compact();

        return jwtToken;
    }







}
