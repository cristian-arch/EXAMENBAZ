package com.example.curso.repository;

import com.example.curso.model.Tutorial;
import com.example.curso.model.usuarios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuariosRepository  extends JpaRepository<usuarios, Long> {
}
