package com.example.curso.util;



import java.io.BufferedReader;
import java.io.Reader;
import java.sql.Clob;
import java.sql.Connection;
import java.util.ArrayList;

public class StringUtils {

	public static String clobToString(Clob data) {
		StringBuilder sb = new StringBuilder();
		try {
			Reader reader = data.getCharacterStream();
			BufferedReader br = new BufferedReader(reader);
			int b;
			while (-1 != (b = br.read())) {
				sb.append((char) b);
			}

			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}


	public static String cortarAcuatroMil(String cad) {
		StringBuilder sb = new StringBuilder("");
		if(cad!=null || cad!=""){
		if(cad.length() > 3900) {
			for(int i = 0; i < 3900; i++) {
				sb.append(cad.charAt(i));
			}
		}else {
			return cad;
		}}else{
			sb.append("");
		}

		return sb.toString();
	}

	public static String fechaExpiracionPay(String fechaOriginal) {
		String[] partes = fechaOriginal.split("/");
		return partes[0] + partes[1];
	}

	public static ArrayList<String> dividirCadenaInsertClob(String cad) {
		int acum = 0;
		StringBuilder sb = new StringBuilder("");
		ArrayList<String> cadList = new ArrayList<String>();
		for (int i = 0; i < cad.length(); i++) {
			if (acum == 2489) {
				sb.append(cad.charAt(i));
				cadList.add(sb.toString());
				sb = new StringBuilder("");
				acum = 0;
			} else {
				sb.append(cad.charAt(i));
				acum++;
			}
		}
		if (acum != 0) {
			cadList.add(sb.toString());
		}
		return cadList;
	}

	public static boolean validarCadena(String cadena) {
		return (!cadena.isEmpty() && null != cadena)? true:false;
	}

	public static String obtenerUltimosNCaracteres(String cadena, int numeroCaracteres) {
		if(cadena.length() < numeroCaracteres) {
			return "noPermitida";
		}else {
			return (cadena.length() == numeroCaracteres)?cadena:cadena.substring(cadena.length()-numeroCaracteres,cadena.length());
		}
	}
}
