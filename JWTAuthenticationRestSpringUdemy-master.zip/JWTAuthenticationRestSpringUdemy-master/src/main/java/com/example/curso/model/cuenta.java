package com.example.curso.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="cuenta")
public class cuenta extends batchResponse{

    public cuenta() {

    }

    public cuenta( int numeroCuenta, float ingresos, usuarios idUsuario, Direccion idDireccion) {

        this.numeroCuenta = numeroCuenta;
        this.ingresos = ingresos;
        this.idUsuario = idUsuario;
        this.idDireccion = idDireccion;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;


    @Column(name = "numeroCuenta")
    private int numeroCuenta;

    @Column(name = "ingresos")
    private float  ingresos;


    @ManyToOne
    @JoinColumn(name = "idUsuario")
    usuarios idUsuario  ;


    @ManyToOne
    @JoinColumn(name = "idDireccion")
    Direccion  idDireccion;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public float getIngresos() {
        return ingresos;
    }

    public void setIngresos(float ingresos) {
        this.ingresos = ingresos;
    }

    public usuarios getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(usuarios idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Direccion getIdDireccion() {
        return idDireccion;
    }

    public void setIdDireccion(Direccion idDireccion) {
        this.idDireccion = idDireccion;
    }
}
