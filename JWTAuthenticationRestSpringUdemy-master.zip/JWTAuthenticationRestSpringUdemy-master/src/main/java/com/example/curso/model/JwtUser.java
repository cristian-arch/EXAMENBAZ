package com.example.curso.model;

public class JwtUser {
	private String userName;
	private long id;
	private String role;
	private String tran_NumeroPlastico;
	private String tran_TipoTarjeta;
	private String descSubProducto;
	private String divisaCuenta;
	private String tran_TipoProducto;
	private String tran_TipoSubProducto;
	private String tran_Plastico;
	private String tran_cuenta;


	public String getTran_cuenta() {
		return tran_cuenta;
	}

	public void setTran_cuenta(String tran_cuenta) {
		this.tran_cuenta = tran_cuenta;
	}

	public String getTran_Plastico() {
		return tran_Plastico;
	}

	public void setTran_Plastico(String tran_Plastico) {
		this.tran_Plastico = tran_Plastico;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	public String getTran_NumeroPlastico() {
		return tran_NumeroPlastico;
	}

	public void setTran_NumeroPlastico(String tran_NumeroPlastico) {
		this.tran_NumeroPlastico = tran_NumeroPlastico;
	}

	public String getTran_TipoTarjeta() {
		return tran_TipoTarjeta;
	}

	public void setTran_TipoTarjeta(String tran_TipoTarjeta) {
		this.tran_TipoTarjeta = tran_TipoTarjeta;
	}

	public String getDescSubProducto() {
		return descSubProducto;
	}

	public void setDescSubProducto(String descSubProducto) {
		this.descSubProducto = descSubProducto;
	}

	public String getDivisaCuenta() {
		return divisaCuenta;
	}

	public void setDivisaCuenta(String divisaCuenta) {
		this.divisaCuenta = divisaCuenta;
	}

	public String getTran_TipoProducto() {
		return tran_TipoProducto;
	}

	public void setTran_TipoProducto(String tran_TipoProducto) {
		this.tran_TipoProducto = tran_TipoProducto;
	}

	public String getTran_TipoSubProducto() {
		return tran_TipoSubProducto;
	}

	public void setTran_TipoSubProducto(String tran_TipoSubProducto) {
		this.tran_TipoSubProducto = tran_TipoSubProducto;
	}

}
