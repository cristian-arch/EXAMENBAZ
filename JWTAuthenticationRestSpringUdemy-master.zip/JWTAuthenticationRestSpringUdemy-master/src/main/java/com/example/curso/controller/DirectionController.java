package com.example.curso.controller;

import com.example.curso.model.Direccion;
import com.example.curso.model.Tutorial;
import com.example.curso.model.batchResponse;
import com.example.curso.repository.DirectionRepository;
import com.example.curso.repository.TutorialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class DirectionController {

    @Autowired
    DirectionRepository directionRepository;

    @PostMapping("/SaveDirection")
    public ResponseEntity<Direccion> SaveDirection(@RequestBody Direccion direccion) {
       if (direccion.getCodigoPostal().length()==6 ) {

           try {
               Direccion _direccion = directionRepository
                       .save(new Direccion(direccion.getCodigoPostal(), direccion.getEstadol()));
               _direccion.setMensaje("Exitoso");
               _direccion.setEstatus(true);
               return new ResponseEntity<>(_direccion, HttpStatus.CREATED);
           } catch (Exception e) {
               direccion.setMensaje("No exitoso");
               direccion.setEstatus(false);
               return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
           }
       }
        else {
           direccion.setCodigoPostal( null);
           direccion.setEstatus(false);
           direccion.setMensaje("el tamaño de codigo postal no es correcto debe tener 6 caracteres");
           return new ResponseEntity<>(direccion, HttpStatus.LENGTH_REQUIRED);
       }
    }


    @GetMapping("/ConsulDirection")
    public ResponseEntity<List<Direccion>> getAllTutorials(@RequestParam(required = false) String codigoPostal) {
        try {
            List<Direccion> direccions = new ArrayList<Direccion>();
            if (codigoPostal == null)
                directionRepository.findAll().forEach(direccions::add);

            if (direccions.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(direccions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/directionById/{id}")
    public ResponseEntity<Direccion> directionById(@PathVariable("id") long id) {
        Optional<Direccion> direccion = directionRepository.findById(id);
        if (direccion.isPresent()) {
            return new ResponseEntity<>(direccion.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PutMapping("/updateDirection/{id}")
    public ResponseEntity<Direccion> updateDirection(@PathVariable("id") long id, @RequestBody Direccion direccion) {
        Optional<Direccion> tutorialData = directionRepository.findById(id);
        if (tutorialData.isPresent()) {
            Direccion _direcction = tutorialData.get();
            _direcction.setCodigoPostal(direccion.getCodigoPostal());
            _direcction.setEstadol(direccion.getEstadol());

            return new ResponseEntity<>(directionRepository.save(_direcction), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/deleteDirection/{id}")
    public ResponseEntity<HttpStatus> deleteDirection(@PathVariable("id") long id) {
        try {
            directionRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
