package com.example.curso.model;

import com.sun.istack.internal.NotNull;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name="direccion")
public class Direccion extends batchResponse  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;


    public Direccion() {
    }

    public Direccion(String codigoPostal, String estadol) {
        this.codigoPostal = codigoPostal;
        this.estadol = estadol;
    }

    @NotNull
    @NotBlank(message = "dato es requerido")
    @Size( max = 6)
    @Column(name = "codigoPostal")
    private String codigoPostal;

    @Column(name = "estadol")

    private String estadol;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getEstadol() {
        return estadol;
    }

    public void setEstadol(String estadol) {
        this.estadol = estadol;
    }
}
