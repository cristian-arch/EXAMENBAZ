package com.example.curso.util;



import com.example.curso.constants.Constants;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class FechasUtils {

	public static String formatoFechaExpiracion(Timestamp fechaExpiracion) {
		SimpleDateFormat formatter = new SimpleDateFormat("MMyy");
		return formatter.format(fechaExpiracion);
	}

	public static Timestamp stringATimestamp(String strFecha,String formato) {
		Timestamp timestamp = null;
		try {
			DateFormat formatter = new SimpleDateFormat(formato);
			Date fecha = formatter.parse(strFecha);
			timestamp = new Timestamp(fecha.getTime());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return timestamp;
	}

	public String obtenerFechaActual(){

		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		Date fechaActual = cal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.formatoFechaHoraGeneral);
		return sdf.format(fechaActual);

	}
	public String sumarMinutosFecha(int minutosMax){

		String fechaAumentada="";
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		Date fechaAument = cal.getTime();

		cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE)+ minutosMax);
		fechaAument = cal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.formatoFechaHoraGeneral);

		return sdf.format(fechaAument);

	}

	public boolean fechaValidator(String fechaExpiration) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat(Constants.formatoFechaHoraGeneral);

		Date fechaActual = sdf.parse(obtenerFechaActual());
		Date fechaRegExp = sdf.parse(fechaExpiration);
		boolean statusexp=false;

		if(fechaActual.before(fechaRegExp)){
			statusexp=true;

		}else{
			statusexp=false;
		}

		return statusexp;
	}
	public String obtenerFechaAAMMDD(String fecha){

		System.out.println("length de fecha es ->"+fecha.length());
		String fechaAAMMDD="";
		int indexPos=10;
		if(fecha.length()==9){
			indexPos=9;
		}
		if (fecha!=null && fecha!="" && fecha.length()>=9){
			fechaAAMMDD=fecha.substring(0,indexPos);
		}else{
			fechaAAMMDD="";
		}
		return fechaAAMMDD;
	}
	public String obtenerAnnio(String fecha){
		String annio="",fech="";

		if(fecha!="" && fecha!=null){
			fech=obtenerFechaAAMMDD(fecha);
			String data[]=fech.split("/");
			annio=data[0];
		}else{
			annio="";
		}
		return annio;
	}

	public String obtenerDia(String fecha){
		String annio="",fech="";

		if(fecha!="" && fecha!=null){
			fech=obtenerFechaAAMMDD(fecha);
			String data[]=fech.split("/");
			annio=data[2];
		}else{
			annio="";
		}
		return annio;
	}

	public String obtenerMes(String fecha){
		String annio="",fech="";

		if(fecha!="" && fecha!=null){
			fech=obtenerFechaAAMMDD(fecha);
			String data[]=fech.split("/");
			annio=data[1];
		}else{
			annio="";
		}
		return annio;
	}

	public String obtenerMesCadena(String fecha) {

		String mesDes = "", mes = "";
		if (fecha != "" && fecha != null) {

			mes = obtenerMes(fecha);
			if (mes.equals("1") || mes.equals("01")) {
				mesDes = "Enero";
			} else if (mes.equals("1") || mes.equals("01")) {
				mesDes = "Febrero";
			} else if (mes.equals("3") || mes.equals("03")) {
				mesDes = "Marzo";
			} else if (mes.equals("4") || mes.equals("04")) {
				mesDes = "Abril";
			} else if (mes.equals("5") || mes.equals("05")) {
				mesDes = "Mayo";
			} else if (mes.equals("6") || mes.equals("06")) {
				mesDes = "Junio";
			} else if (mes.equals("7") || mes.equals("07")) {
				mesDes = "Julio";
			} else if (mes.equals("8") || mes.equals("08")) {
				mesDes = "Agosto";
			} else if (mes.equals("9") || mes.equals("09")) {
				mesDes = "Septiembre";
			} else if (mes.equals("10")) {
				mesDes = "Octubre";
			} else if (mes.equals("11")) {
				mesDes = "Noviembre";
			} else if (mes.equals("12")) {
				mesDes = "Diciembre";
			} else {
				mesDes = "No existe mes";
			}

		}
		return mesDes;
	}
}
